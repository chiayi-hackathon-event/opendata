#!/bin/bash
# rm pig.log
rm -r pig_*.log &> /dev/null
# first
dos2unix Data/*.csv
mac2unix Data/*.csv
cp Data/factory.csv Data/factory.csv.bk
cp Data/stations.csv Data/stations.csv.bk
cp Data/gas-station.csv Data/gas-station.csv.bk
cp Data/slaughterhouses365.csv Data/slaughterhouses365.csv.bk
sed -i '1d' Data/factory.csv
sed -i '1d' Data/stations.csv
sed -i '1d' Data/gas-station.csv
sed -i '1d' Data/slaughterhouses365.csv
sed -i 's| ||g' Data/factory.csv
sed -i 's|　||g' Data/factory.csv
sed -i 's|","|\||g' Data/factory.csv
sed -i 's|"||g' Data/factory.csv
# output
pig -x local output_1.pig
# create final.csv
mkdir final_data &> /dev/null
cat data_all/part* > final_data/data_all.csv
# delete number in final_kaohsiung.csv $3
sed -i 's|,[0-9][0-9]|,|g' final_data/data_all.csv
sed -i 's/|[0-9][0-9]/|/g' final_data/data_all.csv
# remove folder
rm -r data_all &> /dev/null
