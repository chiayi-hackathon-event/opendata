#!/bin/bash
# rm pig.log
rm -r pig_*.log &> /dev/null
# output
pig -x local output_2.pig
# create final.csv
mkdir final_data &> /dev/null
echo 'Name|Address|class|lat|lng' > final_data/final_data.txt
cat data_final/part* | sort -u >> final_data/final_data.txt
# create class list
i=1
echo -n '' > final_data/class_list.txt
input=$(cat data_final/part* | awk -F'|' '{print $3}' | awk -F',' '{print $1}' | sort -ru | sed '/^$/d' | xargs)
for input in $input;do
	echo "class$i|$input" >> final_data/class_list.txt
	sed -i "s|$input|class$i\":\"1|g" final_data/final_data.txt
	i=$(($i+1))
done
# json
echo 'Please 2json ... ...'
./2json.sh final_data/final_data.txt
cat final_data/final_data.txt.json | sed 's|"class":||g' | sed 's|:"1,|:"1","|g' > final_data/final_data.json
# remove clean
#rm -r data_final &> /dev/null
#rm -r final_data/final_data.txt.json &> /dev/null
