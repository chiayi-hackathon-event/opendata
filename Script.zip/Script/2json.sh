#!/bin/bash
echo -n '' > $1.json
declare -A MYARRAY
# get source value
i=1
while read line;do
	for j in $(seq $(echo $line | awk -F'|' '{print NF}'));do
		echo "$line" | cut -d '|' -f $j | grep '[0-9].*[0-9]\.[0-9].*[0-9]' &> /dev/null
		if [ "$?" != "0" ];then
			MYARRAY[$i,$j]=\"$(echo "$line" | cut -d '|' -f $j)\"
		else
			MYARRAY[$i,$j]=$(echo "$line" | cut -d '|' -f $j)
		fi
	done
	i=$(($i+1))
done < $1
# transfer to json
i=2
echo '[' >> $1.json
while true;do
	echo '{' >> $1.json
	for ((j=1; j<${#MYARRAY[@]}; j++));do
		if [ "${MYARRAY[1,$j]}" != "" ];then
			if [ "${MYARRAY[1,$(($j+1))]}" != "" ];then
				echo ${MYARRAY[1,$j]}:${MYARRAY[$i,$j]}, >> $1.json
			else
				echo ${MYARRAY[1,$j]}:${MYARRAY[$i,$j]} >> $1.json
			fi
		else
			break
		fi
	done
	if [ "${MYARRAY[$(($i+1)),1]}" != "" ];then
		echo '},' >> $1.json
	else
		echo '}' >> $1.json
		break
	fi
	i=$(($i+1))
done
echo ']' >> $1.json
