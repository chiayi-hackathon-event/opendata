#!/bin/bash
echo -n '' > final_data/add_lat_lng.csv

key[1]='AIzaSyCwHe2rsjFysHWY_qch7lEziTBT0TT5AvA'
key[2]='AIzaSyCDy1V4GesoSDe2YVS5bMgHJ5NePHg8geg'
key[3]='AIzaSyB_OOSPA4p9E2Usxm2BPoPF3Gfrv6NxcvY'
key[4]='AIzaSyBsTHygRL6JCovU-xyrTRAkW0QCPelMcYY'
key[5]='AIzaSyDQozKiW8zmAkEX1FKypUkHvzUabR3n5TM'

i=1
while read line; do
	add=$(echo $line | awk -F'|' '{print $2}')
	j=1
	while true; do
		cul=$(curl -s "https://maps.googleapis.com/maps/api/geocode/json?address=$add&key=${key[$j]}")
		if [ "$(echo $cul | jq -r .status)" == "OK"  ];then
			lat=$(echo $cul | jq -r .results[0].geometry.location.lat)
			lng=$(echo $cul | jq -r .results[0].geometry.location.lng)
			echo "i=$i,j=$j,key=${key[$j]},$i,$add,$lat,$lng"
			echo "$i,$add,$lat,$lng" >> final_data/add_lat_lng.csv
			i=$(($i+1))
			break
		else
			if [ "$j" == "5" ];then
				break
			else
				j=$(($j+1))
			fi
		fi
		echo "i=$i,j=$j,key=${key[$j]}"
	done
done < final_data/data_all.csv
